package com.petal.handsfree.processor

import android.content.Context
import android.util.Log
import com.petal.handsfree.client.GeminiClient
import com.petal.handsfree.utils.CallHandler
import com.petal.handsfree.utils.NavigationHandler
import kotlinx.coroutines.*
import java.util.regex.Pattern

/**
 * VoiceProcessor - Processes voice commands and executes actions
 * 
 * Flow:
 * 1. Try offline pattern matching first (fast)
 * 2. If no match, send to Gemini API (online)
 * 3. Execute the determined action
 * 4. Return response for TTS
 * 
 * @author Petal Team
 * @version 1.0.0
 */
class VoiceProcessor(private val context: Context) {

    companion object {
        private const val TAG = "VoiceProcessor"
        
        // Supported intents
        const val INTENT_CALL = "CALL"
        const val INTENT_NAVIGATE = "NAVIGATE"
        const val INTENT_SAY = "SAY"
        const val INTENT_BATTERY = "BATTERY"
        const val INTENT_TIME = "TIME"
        const val INTENT_UNKNOWN = "UNKNOWN"
    }

    private val geminiClient = GeminiClient()
    private val callHandler = CallHandler(context)
    private val navigationHandler = NavigationHandler(context)
    
    // Offline regex patterns for quick local processing
    private val offlinePatterns = mapOf(
        // Call patterns
        Pattern.compile(
            "(?:llama(?:r)?|marcar?|telefono|llamada)\\s+(?:a|al)?\\s*([0-9\\s+\\-().]{7,15})",
            Pattern.CASE_INSENSITIVE
        ) to INTENT_CALL,
        
        // Navigation patterns
        Pattern.compile(
            "(?:ir|ve|vamos|navega|llev(?:a|ame)|direccion)\\s+(?:a|al|hacia)?\\s*(.+)",
            Pattern.CASE_INSENSITIVE
        ) to INTENT_NAVIGATE,
        
        // Battery patterns
        Pattern.compile(
            "(?:bateria|batería|nivel|carga|energia|energía)",
            Pattern.CASE_INSENSITIVE
        ) to INTENT_BATTERY,
        
        // Time patterns
        Pattern.compile(
            "(?:que\\s+hora|hora|tiempo|reloj)",
            Pattern.CASE_INSENSITIVE
        ) to INTENT_TIME
    )

    /**
     * Process voice command and execute action
     * 
     * @param spokenText The recognized speech text
     * @param onResponse Callback with the response to speak
     */
    suspend fun processVoiceCommand(
        spokenText: String,
        onResponse: (String) -> Unit
    ) {
        Log.d(TAG, "Processing voice command: '$spokenText'")
        
        try {
            // Step 1: Try offline processing first
            val offlineResult = tryOfflineProcessing(spokenText)
            
            if (offlineResult != null) {
                Log.d(TAG, "Processed offline: ${offlineResult.intent}")
                executeAction(offlineResult.intent, offlineResult.argument, onResponse)
                return
            }
            
            // Step 2: Use Gemini API for complex queries
            Log.d(TAG, "Trying online processing with Gemini")
            
            val geminiResult = withContext(Dispatchers.IO) {
                geminiClient.processVoiceCommand(spokenText)
            }
            
            if (geminiResult != null) {
                Log.d(TAG, "Processed online: ${geminiResult.intent}")
                executeAction(geminiResult.intent, geminiResult.argument, onResponse)
            } else {
                // Fallback response
                onResponse("Lo siento, no entendí tu comando. Puedes intentar con: llamar a un número, ir a un lugar, o preguntar la batería.")
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Error processing voice command", e)
            onResponse("Lo siento, hubo un error procesando tu comando.")
        }
    }

    /**
     * Try to process command using offline patterns
     * 
     * @param spokenText The speech to analyze
     * @return ProcessingResult if matched, null otherwise
     */
    private fun tryOfflineProcessing(spokenText: String): ProcessingResult? {
        for ((pattern, intent) in offlinePatterns) {
            val matcher = pattern.matcher(spokenText)
            if (matcher.find()) {
                
                val argument = when (intent) {
                    INTENT_CALL -> {
                        // Extract and clean phone number
                        val phoneNumber = matcher.group(1)?.replace(Regex("[^0-9+]"), "") ?: ""
                        phoneNumber
                    }
                    INTENT_NAVIGATE -> {
                        // Extract destination
                        matcher.group(1)?.trim() ?: ""
                    }
                    INTENT_BATTERY, INTENT_TIME -> {
                        // No argument needed
                        ""
                    }
                    else -> matcher.group(1)?.trim() ?: ""
                }
                
                return ProcessingResult(intent, argument)
            }
        }
        return null
    }

    /**
     * Execute the determined action
     * 
     * @param intent The action intent
     * @param argument The action argument
     * @param onResponse Callback with response
     */
    private suspend fun executeAction(
        intent: String,
        argument: String,
        onResponse: (String) -> Unit
    ) {
        when (intent) {
            INTENT_CALL -> handleCallAction(argument, onResponse)
            INTENT_NAVIGATE -> handleNavigationAction(argument, onResponse)
            INTENT_SAY -> onResponse(argument)
            INTENT_BATTERY -> handleBatteryAction(onResponse)
            INTENT_TIME -> handleTimeAction(onResponse)
            else -> onResponse("Comando no reconocido: $intent")
        }
    }

    /**
     * Handle call action
     */
    private suspend fun handleCallAction(phoneNumber: String, onResponse: (String) -> Unit) {
        if (phoneNumber.isEmpty()) {
            onResponse("No detecté un número de teléfono válido.")
            return
        }
        
        if (phoneNumber.length < 7) {
            onResponse("El número de teléfono parece muy corto.")
            return
        }
        
        try {
            val success = callHandler.makeCall(phoneNumber)
            if (success) {
                onResponse("Llamando a $phoneNumber")
            } else {
                onResponse("No pude iniciar la llamada. Revisa los permisos.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error making call", e)
            onResponse("Error al intentar hacer la llamada.")
        }
    }

    /**
     * Handle navigation action
     */
    private suspend fun handleNavigationAction(destination: String, onResponse: (String) -> Unit) {
        if (destination.isEmpty()) {
            onResponse("No especificaste un destino.")
            return
        }
        
        try {
            val success = navigationHandler.navigateToDestination(destination)
            if (success) {
                onResponse("Navegando a $destination en modo bicicleta")
            } else {
                onResponse("No pude abrir la navegación. ¿Tienes Google Maps instalado?")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error navigating", e)
            onResponse("Error al abrir la navegación.")
        }
    }

    /**
     * Handle battery status request
     */
    private fun handleBatteryAction(onResponse: (String) -> Unit) {
        try {
            val batteryLevel = getBatteryLevel()
            onResponse("El nivel de batería es del $batteryLevel por ciento")
        } catch (e: Exception) {
            Log.e(TAG, "Error getting battery level", e)
            onResponse("No pude obtener el nivel de batería.")
        }
    }

    /**
     * Handle time request
     */
    private fun handleTimeAction(onResponse: (String) -> Unit) {
        try {
            val currentTime = getCurrentTime()
            onResponse("Son las $currentTime")
        } catch (e: Exception) {
            Log.e(TAG, "Error getting time", e)
            onResponse("No pude obtener la hora actual.")
        }
    }

    /**
     * Get current battery level
     */
    private fun getBatteryLevel(): Int {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
        return batteryManager.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    /**
     * Get current time formatted for speech
     */
    private fun getCurrentTime(): String {
        val calendar = java.util.Calendar.getInstance()
        val hour = calendar.get(java.util.Calendar.HOUR_OF_DAY)
        val minute = calendar.get(java.util.Calendar.MINUTE)
        
        return when {
            minute == 0 -> "$hour en punto"
            minute < 10 -> "$hour y cero $minute"
            else -> "$hour y $minute"
        }
    }

    /**
     * Data class for processing results
     */
    data class ProcessingResult(
        val intent: String,
        val argument: String
    )
}