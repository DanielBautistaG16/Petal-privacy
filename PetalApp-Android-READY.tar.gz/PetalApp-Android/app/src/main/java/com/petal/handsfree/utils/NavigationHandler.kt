package com.petal.handsfree.utils

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log

/**
 * NavigationHandler - Manages navigation functionality
 * 
 * Handles:
 * - Google Maps integration
 * - Bike-specific navigation
 * - Destination parsing and formatting
 * - Fallback navigation options
 * 
 * @author Petal Team
 * @version 1.0.0
 */
class NavigationHandler(private val context: Context) {

    companion object {
        private const TAG = "NavigationHandler"
        
        // Navigation apps package names
        private const val GOOGLE_MAPS_PACKAGE = "com.google.android.apps.maps"
        private const val WAZE_PACKAGE = "com.waze"
        
        // Common location keywords in Spanish
        private val LOCATION_KEYWORDS = mapOf(
            "casa" to "home",
            "trabajo" to "work",
            "oficina" to "office",
            "hospital" to "hospital",
            "farmacia" to "pharmacy",
            "supermercado" to "supermarket",
            "gasolinera" to "gas station",
            "restaurante" to "restaurant",
            "banco" to "bank",
            "centro comercial" to "shopping center"
        )
    }

    /**
     * Navigate to specified destination using bike mode
     * 
     * @param destination The destination to navigate to
     * @return true if navigation was started successfully, false otherwise
     */
    fun navigateToDestination(destination: String): Boolean {
        Log.d(TAG, "Navigating to: $destination")

        val processedDestination = processDestination(destination)
        
        return try {
            when {
                isGoogleMapsAvailable() -> navigateWithGoogleMaps(processedDestination)
                isWazeAvailable() -> navigateWithWaze(processedDestination)
                else -> navigateWithWebMaps(processedDestination)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error starting navigation", e)
            false
        }
    }

    /**
     * Navigate using Google Maps with bike mode
     */
    private fun navigateWithGoogleMaps(destination: String): Boolean {
        return try {
            // Try navigation intent first (most precise)
            val navIntent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("google.navigation:q=${Uri.encode(destination)}&mode=b")
                setPackage(GOOGLE_MAPS_PACKAGE)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            
            if (navIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(navIntent)
                Log.i(TAG, "Started Google Maps navigation to: $destination")
                return true
            }
            
            // Fallback to general maps intent
            val mapsIntent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("geo:0,0?q=${Uri.encode(destination)}")
                setPackage(GOOGLE_MAPS_PACKAGE)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            
            context.startActivity(mapsIntent)
            Log.i(TAG, "Started Google Maps search for: $destination")
            true
            
        } catch (e: Exception) {
            Log.e(TAG, "Error with Google Maps navigation", e)
            false
        }
    }

    /**
     * Navigate using Waze
     */
    private fun navigateWithWaze(destination: String): Boolean {
        return try {
            val wazeIntent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("waze://?q=${Uri.encode(destination)}&navigate=yes")
                setPackage(WAZE_PACKAGE)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            
            context.startActivity(wazeIntent)
            Log.i(TAG, "Started Waze navigation to: $destination")
            true
            
        } catch (e: Exception) {
            Log.e(TAG, "Error with Waze navigation", e)
            false
        }
    }

    /**
     * Navigate using web-based Google Maps
     */
    private fun navigateWithWebMaps(destination: String): Boolean {
        return try {
            val webIntent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("https://www.google.com/maps/dir/?api=1&destination=${Uri.encode(destination)}&travelmode=bicycling")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            
            context.startActivity(webIntent)
            Log.i(TAG, "Started web navigation to: $destination")
            true
            
        } catch (e: Exception) {
            Log.e(TAG, "Error with web navigation", e)
            false
        }
    }

    /**
     * Process and enhance destination string
     */
    private fun processDestination(destination: String): String {
        var processed = destination.trim()
        
        // Handle common Spanish location types
        for ((spanish, english) in LOCATION_KEYWORDS) {
            if (processed.lowercase().contains(spanish)) {
                processed = processed.lowercase().replace(spanish, english)
            }
        }
        
        // Add context if destination seems too generic
        processed = addLocationContext(processed)
        
        return processed
    }

    /**
     * Add location context for better search results
     */
    private fun addLocationContext(destination: String): String {
        val lowercaseDestination = destination.lowercase()
        
        // If destination doesn't contain city/location info, add Spanish context
        val hasLocationContext = listOf(
            "valencia", "madrid", "barcelona", "sevilla", "bilbao",
            "españa", "spain", "calle", "avenida", "plaza",
            "centro", "barrio"
        ).any { lowercaseDestination.contains(it) }
        
        return if (!hasLocationContext && destination.length < 20) {
            "$destination Valencia España" // Default to Valencia as per original app
        } else {
            destination
        }
    }

    /**
     * Check if Google Maps is installed and available
     */
    private fun isGoogleMapsAvailable(): Boolean {
        return try {
            context.packageManager.getApplicationInfo(GOOGLE_MAPS_PACKAGE, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    /**
     * Check if Waze is installed and available
     */
    private fun isWazeAvailable(): Boolean {
        return try {
            context.packageManager.getApplicationInfo(WAZE_PACKAGE, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    /**
     * Get available navigation apps
     */
    fun getAvailableNavigationApps(): List<NavigationApp> {
        val availableApps = mutableListOf<NavigationApp>()
        
        if (isGoogleMapsAvailable()) {
            availableApps.add(NavigationApp.GOOGLE_MAPS)
        }
        
        if (isWazeAvailable()) {
            availableApps.add(NavigationApp.WAZE)
        }
        
        // Web maps is always available
        availableApps.add(NavigationApp.WEB_MAPS)
        
        return availableApps
    }

    /**
     * Open Google Maps to show traffic information
     */
    fun showTrafficInfo(): Boolean {
        return try {
            val trafficIntent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("google.navigation:q=current+location&mode=b&layer=traffic")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            
            if (isGoogleMapsAvailable()) {
                trafficIntent.setPackage(GOOGLE_MAPS_PACKAGE)
            }
            
            context.startActivity(trafficIntent)
            Log.i(TAG, "Opened traffic information")
            true
            
        } catch (e: Exception) {
            Log.e(TAG, "Error showing traffic info", e)
            false
        }
    }

    /**
     * Navigate to current location (useful for finding where you are)
     */
    fun showCurrentLocation(): Boolean {
        return try {
            val locationIntent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("geo:0,0?q=current+location")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            
            if (isGoogleMapsAvailable()) {
                locationIntent.setPackage(GOOGLE_MAPS_PACKAGE)
            }
            
            context.startActivity(locationIntent)
            Log.i(TAG, "Showing current location")
            true
            
        } catch (e: Exception) {
            Log.e(TAG, "Error showing current location", e)
            false
        }
    }

    /**
     * Navigation app enum
     */
    enum class NavigationApp(val displayName: String) {
        GOOGLE_MAPS("Google Maps"),
        WAZE("Waze"),
        WEB_MAPS("Maps (Web)")
    }

    /**
     * Navigation result data class
     */
    data class NavigationResult(
        val success: Boolean,
        val app: NavigationApp,
        val destination: String,
        val error: String? = null
    )
}