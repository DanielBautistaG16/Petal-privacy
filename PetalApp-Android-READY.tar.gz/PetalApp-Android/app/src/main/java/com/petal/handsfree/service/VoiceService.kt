package com.petal.handsfree.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import com.petal.handsfree.MainActivity
import com.petal.handsfree.R
import com.petal.handsfree.processor.VoiceProcessor
import com.petal.handsfree.utils.TtsHelper
import kotlinx.coroutines.*
import java.util.*

/**
 * VoiceService - Core foreground service for hands-free functionality
 * 
 * Responsibilities:
 * - Maintain continuous speech recognition
 * - Process voice commands
 * - Execute actions (call, navigate, respond)
 * - Maintain foreground notification
 * - Handle wake lock for reliability
 * 
 * @author Petal Team
 * @version 1.0.0
 */
class VoiceService : LifecycleService(), RecognitionListener, TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_START_SERVICE = "com.petal.handsfree.START_SERVICE"
        const val ACTION_STOP_SERVICE = "com.petal.handsfree.STOP_SERVICE"
        
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "PetalHandsfreeChannel"
        private const val TAG = "VoiceService"
        
        @Volatile
        var isRunning: Boolean = false
            private set
    }

    // Core components
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var voiceProcessor: VoiceProcessor? = null
    private var ttsHelper: TtsHelper? = null

    // System components
    private var wakeLock: PowerManager.WakeLock? = null
    private var notificationManager: NotificationManager? = null

    // Coroutine management
    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.Main + serviceJob)

    // State management
    private var isListening = false
    private var isTtsReady = false
    private var restartAttempts = 0
    private val maxRestartAttempts = 3

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "VoiceService created")
        
        initializeService()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        
        when (intent?.action) {
            ACTION_START_SERVICE -> {
                startHandsfreeMode()
            }
            ACTION_STOP_SERVICE -> {
                stopSelf()
            }
        }
        
        return START_STICKY // Restart service if killed by system
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null // No binding needed
    }

    override fun onDestroy() {
        Log.d(TAG, "VoiceService destroyed")
        cleanupService()
        super.onDestroy()
    }

    /**
     * Initialize all service components
     */
    private fun initializeService() {
        // Create notification channel
        createNotificationChannel()
        
        // Initialize notification manager
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        
        // Initialize wake lock
        initializeWakeLock()
        
        // Initialize voice processor
        voiceProcessor = VoiceProcessor(this)
        
        // Initialize TTS helper
        ttsHelper = TtsHelper(this) { isTtsReady ->
            this.isTtsReady = isTtsReady
            if (isTtsReady) {
                sayWelcomeMessage()
            }
        }
        
        // Initialize TextToSpeech
        textToSpeech = TextToSpeech(this, this)
    }

    /**
     * Start hands-free mode
     */
    private fun startHandsfreeMode() {
        if (isRunning) {
            Log.w(TAG, "Service already running")
            return
        }
        
        Log.i(TAG, "Starting hands-free mode")
        
        // Start foreground service
        startForeground(NOTIFICATION_ID, createNotification("Iniciando..."))
        
        // Acquire wake lock
        wakeLock?.acquire(10*60*1000L /*10 minutes*/)
        
        // Initialize speech recognizer
        initializeSpeechRecognizer()
        
        isRunning = true
        
        // Start listening after TTS is ready
        serviceScope.launch {
            waitForTtsReady()
            startListening()
        }
    }

    /**
     * Initialize wake lock for service reliability
     */
    private fun initializeWakeLock() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "PetalApp::VoiceServiceWakeLock"
        ).apply {
            setReferenceCounted(false)
        }
    }

    /**
     * Initialize speech recognizer
     */
    private fun initializeSpeechRecognizer() {
        if (speechRecognizer != null) {
            speechRecognizer?.destroy()
        }
        
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(this@VoiceService)
        }
        
        Log.d(TAG, "Speech recognizer initialized")
    }

    /**
     * Start speech recognition
     */
    private fun startListening() {
        if (isListening) {
            Log.w(TAG, "Already listening")
            return
        }
        
        val intent = android.speech.RecognizerIntent().apply {
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, 
                    android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(android.speech.RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        
        try {
            speechRecognizer?.startListening(intent)
            isListening = true
            updateNotification("Escuchando...")
            Log.d(TAG, "Started listening")
        } catch (e: Exception) {
            Log.e(TAG, "Error starting speech recognition", e)
            handleRecognitionError()
        }
    }

    /**
     * Stop speech recognition
     */
    private fun stopListening() {
        if (!isListening) return
        
        try {
            speechRecognizer?.stopListening()
            isListening = false
            Log.d(TAG, "Stopped listening")
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping speech recognition", e)
        }
    }

    /**
     * Wait for TTS to be ready
     */
    private suspend fun waitForTtsReady() {
        var attempts = 0
        while (!isTtsReady && attempts < 50) { // Wait up to 5 seconds
            delay(100)
            attempts++
        }
    }

    /**
     * Say welcome message
     */
    private fun sayWelcomeMessage() {
        ttsHelper?.speak("Petal manos libres activo. Te escucho.")
    }

    // RecognitionListener implementation
    override fun onReadyForSpeech(params: Bundle?) {
        Log.d(TAG, "Ready for speech")
        updateNotification("Te escucho...")
    }

    override fun onBeginningOfSpeech() {
        Log.d(TAG, "Beginning of speech")
        updateNotification("Escuchando...")
    }

    override fun onRmsChanged(rmsdB: Float) {
        // Audio level changed - could be used for UI updates
    }

    override fun onBufferReceived(buffer: ByteArray?) {
        // Audio buffer received
    }

    override fun onEndOfSpeech() {
        Log.d(TAG, "End of speech")
        updateNotification("Procesando...")
        isListening = false
    }

    override fun onError(error: Int) {
        val errorMessage = when (error) {
            SpeechRecognizer.ERROR_AUDIO -> "Error de audio"
            SpeechRecognizer.ERROR_CLIENT -> "Error del cliente"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Permisos insuficientes"
            SpeechRecognizer.ERROR_NETWORK -> "Error de red"
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Timeout de red"
            SpeechRecognizer.ERROR_NO_MATCH -> "No se encontró coincidencia"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Reconocedor ocupado"
            SpeechRecognizer.ERROR_SERVER -> "Error del servidor"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Timeout de voz"
            else -> "Error desconocido: $error"
        }
        
        Log.w(TAG, "Speech recognition error: $errorMessage")
        
        isListening = false
        
        // Don't restart on "no match" errors - just continue listening
        if (error != SpeechRecognizer.ERROR_NO_MATCH) {
            handleRecognitionError()
        } else {
            // Restart listening after a short delay
            serviceScope.launch {
                delay(1000)
                if (isRunning) {
                    startListening()
                }
            }
        }
    }

    override fun onResults(results: Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (matches.isNullOrEmpty()) {
            Log.w(TAG, "No recognition results")
            restartListening()
            return
        }
        
        val spokenText = matches[0]
        Log.i(TAG, "Speech recognized: '$spokenText'")
        
        updateNotification("Procesando: \"$spokenText\"")
        
        // Process the spoken text
        serviceScope.launch {
            try {
                voiceProcessor?.processVoiceCommand(spokenText) { response ->
                    // Speak the response
                    ttsHelper?.speak(response) {
                        // Restart listening after TTS completes
                        serviceScope.launch {
                            delay(500) // Small delay before restarting
                            if (isRunning) {
                                startListening()
                            }
                        }
                    }
                }
                
                restartAttempts = 0 // Reset attempts on successful processing
                
            } catch (e: Exception) {
                Log.e(TAG, "Error processing voice command", e)
                ttsHelper?.speak("Lo siento, hubo un error procesando tu comando")
                restartListening()
            }
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {
        // Handle partial results if needed
        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            Log.d(TAG, "Partial result: ${matches[0]}")
        }
    }

    override fun onEvent(eventType: Int, params: Bundle?) {
        Log.d(TAG, "Speech recognition event: $eventType")
    }

    // TextToSpeech.OnInitListener implementation
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            textToSpeech?.language = Locale.getDefault()
            isTtsReady = true
            Log.d(TAG, "TTS initialized successfully")
        } else {
            Log.e(TAG, "TTS initialization failed")
            isTtsReady = false
        }
    }

    /**
     * Handle recognition errors with retry logic
     */
    private fun handleRecognitionError() {
        if (restartAttempts < maxRestartAttempts) {
            restartAttempts++
            Log.i(TAG, "Attempting to restart recognition (attempt $restartAttempts)")
            
            serviceScope.launch {
                delay(2000) // Wait 2 seconds before retry
                if (isRunning) {
                    initializeSpeechRecognizer()
                    startListening()
                }
            }
        } else {
            Log.e(TAG, "Max restart attempts reached, service may be unreliable")
            ttsHelper?.speak("Hay problemas con el reconocimiento de voz. Intenta reiniciar la aplicación.")
            updateNotification("Error - Reiniciar recomendado")
        }
    }

    /**
     * Restart listening after processing
     */
    private fun restartListening() {
        serviceScope.launch {
            delay(1000) // Brief pause
            if (isRunning) {
                startListening()
            }
        }
    }

    /**
     * Create notification channel for foreground service
     */
    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Petal Hands-free Service",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Servicio activo para comandos de voz manos libres"
            setShowBadge(false)
            setSound(null, null)
        }
        
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(channel)
    }

    /**
     * Create notification for foreground service
     */
    private fun createNotification(status: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent, 
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🎤 Petal Manos Libres")
            .setContentText(status)
            .setSmallIcon(R.drawable.ic_mic) // TODO: Create this icon
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setAutoCancel(false)
            .build()
    }

    /**
     * Update notification with current status
     */
    private fun updateNotification(status: String) {
        val notification = createNotification(status)
        notificationManager?.notify(NOTIFICATION_ID, notification)
    }

    /**
     * Clean up all service components
     */
    private fun cleanupService() {
        isRunning = false
        
        // Stop listening
        stopListening()
        
        // Destroy speech recognizer
        speechRecognizer?.destroy()
        speechRecognizer = null
        
        // Shutdown TTS
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
        
        // Release wake lock
        wakeLock?.let {
            if (it.isHeld) {
                it.release()
            }
        }
        wakeLock = null
        
        // Cancel all coroutines
        serviceJob.cancel()
        
        // Cleanup other components
        voiceProcessor = null
        ttsHelper = null
        
        Log.i(TAG, "Service cleanup completed")
    }
}