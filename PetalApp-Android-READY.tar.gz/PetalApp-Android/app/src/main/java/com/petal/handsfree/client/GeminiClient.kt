package com.petal.handsfree.client

import android.util.Log
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.petal.handsfree.BuildConfig
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

/**
 * GeminiClient - Handles communication with Google Gemini API
 * 
 * Sends voice commands to Gemini 1.5 Flash model and receives
 * structured JSON responses with intent and argument.
 * 
 * @author Petal Team
 * @version 1.0.0
 */
class GeminiClient {

    companion object {
        private const val TAG = "GeminiClient"
        private const val TIMEOUT_SECONDS = 10L
        
        // Gemini API endpoint
        private const val GEMINI_MODEL = "gemini-1.5-flash"
        
        // System prompt for consistent JSON responses
        private val SYSTEM_PROMPT = """
            Eres un asistente de voz para ciclistas. Analiza el comando de voz y devuelve SOLO un JSON válido con esta estructura:
            {"intent":"ACCION","argument":"argumento"}
            
            Intents disponibles:
            - CALL: para llamadas telefónicas (argument: número limpio sin espacios)
            - NAVIGATE: para navegación (argument: destino completo)  
            - SAY: para respuestas conversacionales (argument: respuesta a decir)
            
            Ejemplos:
            "llama a 611 223 344" → {"intent":"CALL","argument":"611223344"}
            "ir a Casa Carmela" → {"intent":"NAVIGATE","argument":"Casa Carmela Valencia"}
            "¿cómo está el tráfico?" → {"intent":"SAY","argument":"Puedo abrir Google Maps para comprobar el tráfico actual."}
            
            IMPORTANTE: Responde SOLO con JSON válido, sin explicaciones adicionales.
        """.trimIndent()
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(TIMEOUT_SECONDS, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(TIMEOUT_SECONDS, java.util.concurrent.TimeUnit.SECONDS)
        .writeTimeout(TIMEOUT_SECONDS, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    private val gson = Gson()

    /**
     * Process voice command using Gemini API
     * 
     * @param voiceCommand The recognized speech text
     * @return GeminiResponse with intent and argument, or null if failed
     */
    suspend fun processVoiceCommand(voiceCommand: String): GeminiResponse? {
        if (BuildConfig.GEMINI_API_KEY == "ADD_YOUR_KEY_HERE") {
            Log.w(TAG, "Gemini API key not configured")
            return null
        }

        return try {
            val request = createGeminiRequest(voiceCommand)
            val response = client.newCall(request).execute()
            
            if (response.isSuccessful) {
                parseGeminiResponse(response.body?.string())
            } else {
                Log.e(TAG, "Gemini API error: ${response.code} - ${response.message}")
                null
            }
        } catch (e: IOException) {
            Log.e(TAG, "Network error calling Gemini API", e)
            null
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error calling Gemini API", e)
            null
        }
    }

    /**
     * Create HTTP request for Gemini API
     */
    private fun createGeminiRequest(voiceCommand: String): Request {
        val url = "${BuildConfig.GEMINI_BASE_URL}$GEMINI_MODEL:generateContent?key=${BuildConfig.GEMINI_API_KEY}"
        
        val requestBody = GeminiRequest(
            contents = listOf(
                GeminiContent(
                    parts = listOf(
                        GeminiPart(text = "$SYSTEM_PROMPT\n\nComando: \"$voiceCommand\"")
                    )
                )
            ),
            generationConfig = GeminiGenerationConfig(
                temperature = 0.1,
                topK = 1,
                topP = 0.8,
                maxOutputTokens = 100,
                stopSequences = emptyList()
            ),
            safetySettings = listOf(
                GeminiSafetySetting("HARM_CATEGORY_HARASSMENT", "BLOCK_MEDIUM_AND_ABOVE"),
                GeminiSafetySetting("HARM_CATEGORY_HATE_SPEECH", "BLOCK_MEDIUM_AND_ABOVE"),
                GeminiSafetySetting("HARM_CATEGORY_SEXUALLY_EXPLICIT", "BLOCK_MEDIUM_AND_ABOVE"),
                GeminiSafetySetting("HARM_CATEGORY_DANGEROUS_CONTENT", "BLOCK_MEDIUM_AND_ABOVE")
            )
        )

        val json = gson.toJson(requestBody)
        val body = json.toRequestBody("application/json".toMediaTypeOrNull())

        return Request.Builder()
            .url(url)
            .post(body)
            .addHeader("Content-Type", "application/json")
            .build()
    }

    /**
     * Parse Gemini API response and extract JSON
     */
    private fun parseGeminiResponse(responseBody: String?): GeminiResponse? {
        if (responseBody.isNullOrEmpty()) {
            Log.e(TAG, "Empty response from Gemini API")
            return null
        }

        Log.d(TAG, "Gemini raw response: $responseBody")

        return try {
            // Parse the Gemini API response structure
            val apiResponse = gson.fromJson(responseBody, GeminiApiResponse::class.java)
            
            val textContent = apiResponse.candidates
                ?.firstOrNull()
                ?.content
                ?.parts
                ?.firstOrNull()
                ?.text

            if (textContent.isNullOrEmpty()) {
                Log.e(TAG, "No text content in Gemini response")
                return null
            }

            Log.d(TAG, "Gemini text content: $textContent")

            // Extract JSON from the text content
            val jsonMatch = Regex("""\{[^}]*"intent"[^}]*\}""").find(textContent)
            val jsonString = jsonMatch?.value

            if (jsonString == null) {
                Log.e(TAG, "No JSON found in Gemini response")
                return null
            }

            // Parse the extracted JSON
            val geminiResponse = gson.fromJson(jsonString, GeminiResponse::class.java)
            
            Log.d(TAG, "Parsed Gemini response: intent=${geminiResponse.intent}, argument=${geminiResponse.argument}")
            
            geminiResponse

        } catch (e: Exception) {
            Log.e(TAG, "Error parsing Gemini response", e)
            null
        }
    }

    // Data classes for Gemini API request/response

    data class GeminiRequest(
        val contents: List<GeminiContent>,
        val generationConfig: GeminiGenerationConfig,
        val safetySettings: List<GeminiSafetySetting>
    )

    data class GeminiContent(
        val parts: List<GeminiPart>
    )

    data class GeminiPart(
        val text: String
    )

    data class GeminiGenerationConfig(
        val temperature: Double,
        val topK: Int,
        val topP: Double,
        val maxOutputTokens: Int,
        val stopSequences: List<String>
    )

    data class GeminiSafetySetting(
        val category: String,
        val threshold: String
    )

    data class GeminiApiResponse(
        val candidates: List<GeminiCandidate>?
    )

    data class GeminiCandidate(
        val content: GeminiContent?
    )

    /**
     * Response data class for parsed commands
     */
    data class GeminiResponse(
        @SerializedName("intent")
        val intent: String,
        
        @SerializedName("argument")
        val argument: String
    )
}