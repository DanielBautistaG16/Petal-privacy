package com.petal.handsfree.utils

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log
import androidx.core.content.ContextCompat

/**
 * CallHandler - Manages phone call functionality
 * 
 * Handles:
 * - Permission checks for CALL_PHONE
 * - Phone number validation
 * - Call intent creation and execution
 * 
 * @author Petal Team
 * @version 1.0.0
 */
class CallHandler(private val context: Context) {

    companion object {
        private const val TAG = "CallHandler"
        
        // Phone number validation patterns
        private val PHONE_PATTERNS = listOf(
            Regex("^\\+?[0-9]{7,15}$"), // International format
            Regex("^[0-9]{7,10}$"),      // National format
            Regex("^\\+34[0-9]{9}$"),    // Spain format
            Regex("^[6789][0-9]{8}$")    // Spanish mobile
        )
    }

    /**
     * Make a phone call to the specified number
     * 
     * @param phoneNumber The phone number to call
     * @return true if call was initiated successfully, false otherwise
     */
    fun makeCall(phoneNumber: String): Boolean {
        Log.d(TAG, "Attempting to call: $phoneNumber")

        // Check permissions
        if (!hasCallPermission()) {
            Log.e(TAG, "CALL_PHONE permission not granted")
            return false
        }

        // Validate phone number
        val cleanNumber = cleanPhoneNumber(phoneNumber)
        if (!isValidPhoneNumber(cleanNumber)) {
            Log.e(TAG, "Invalid phone number: $cleanNumber")
            return false
        }

        return try {
            val callIntent = createCallIntent(cleanNumber)
            context.startActivity(callIntent)
            
            Log.i(TAG, "Call initiated successfully to: $cleanNumber")
            true
            
        } catch (e: Exception) {
            Log.e(TAG, "Error initiating call", e)
            false
        }
    }

    /**
     * Check if the app has CALL_PHONE permission
     */
    private fun hasCallPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Clean and normalize phone number
     */
    private fun cleanPhoneNumber(phoneNumber: String): String {
        return phoneNumber
            .replace(Regex("[^0-9+]"), "") // Remove everything except digits and +
            .let { cleaned ->
                // Handle Spanish numbers without country code
                when {
                    cleaned.startsWith("0034") -> "+34${cleaned.drop(4)}"
                    cleaned.startsWith("34") && cleaned.length == 11 -> "+$cleaned"
                    cleaned.matches(Regex("^[6789][0-9]{8}$")) -> "+34$cleaned" // Spanish mobile
                    else -> cleaned
                }
            }
    }

    /**
     * Validate phone number format
     */
    private fun isValidPhoneNumber(phoneNumber: String): Boolean {
        if (phoneNumber.isEmpty()) return false
        
        // Check against known patterns
        return PHONE_PATTERNS.any { pattern ->
            pattern.matches(phoneNumber)
        }
    }

    /**
     * Create call intent
     */
    private fun createCallIntent(phoneNumber: String): Intent {
        return Intent(Intent.ACTION_CALL).apply {
            data = Uri.parse("tel:$phoneNumber")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
    }

    /**
     * Format phone number for display/speech
     */
    fun formatPhoneNumberForSpeech(phoneNumber: String): String {
        val cleaned = cleanPhoneNumber(phoneNumber)
        
        return when {
            cleaned.startsWith("+34") -> {
                val number = cleaned.drop(3)
                "${number.take(3)} ${number.drop(3).take(3)} ${number.drop(6)}"
            }
            cleaned.startsWith("+") -> {
                // International format - just add spaces every 3 digits
                cleaned.drop(1).chunked(3).joinToString(" ")
            }
            else -> {
                // National format - group appropriately
                when (cleaned.length) {
                    7 -> "${cleaned.take(3)} ${cleaned.drop(3)}"
                    8 -> "${cleaned.take(4)} ${cleaned.drop(4)}"
                    9 -> "${cleaned.take(3)} ${cleaned.drop(3).take(3)} ${cleaned.drop(6)}"
                    10 -> "${cleaned.take(3)} ${cleaned.drop(3).take(3)} ${cleaned.drop(6)}"
                    else -> cleaned.chunked(3).joinToString(" ")
                }
            }
        }
    }

    /**
     * Check if a phone number appears to be an emergency number
     */
    fun isEmergencyNumber(phoneNumber: String): Boolean {
        val cleaned = cleanPhoneNumber(phoneNumber)
        
        val emergencyNumbers = setOf(
            "112", "911", "999", "000", // International
            "+34112", "091", "092", "062", // Spain specific
            "080", "085" // Local emergency
        )
        
        return emergencyNumbers.contains(cleaned)
    }

    /**
     * Get call history (future enhancement)
     */
    fun getRecentCalls(limit: Int = 5): List<CallRecord> {
        // TODO: Implement call history reading
        // Requires READ_CALL_LOG permission
        return emptyList()
    }

    /**
     * Data class for call records
     */
    data class CallRecord(
        val number: String,
        val timestamp: Long,
        val duration: Long,
        val type: CallType
    )

    enum class CallType {
        INCOMING, OUTGOING, MISSED
    }
}