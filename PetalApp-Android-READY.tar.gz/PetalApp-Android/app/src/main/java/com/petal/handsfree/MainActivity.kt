package com.petal.handsfree

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.petal.handsfree.databinding.ActivityMainBinding
import com.petal.handsfree.service.VoiceService
import com.petal.handsfree.viewmodel.MainViewModel

/**
 * MainActivity - Entry point for Petal Hands-free App
 * 
 * Responsibilities:
 * - Request required permissions
 * - Start/Stop VoiceService
 * - Handle battery optimization settings
 * - Display service status
 * 
 * @author Petal Team
 * @version 1.0.0
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel

    // Required permissions for hands-free functionality
    private val requiredPermissions = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.POST_NOTIFICATIONS
    )

    // Permission launcher
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            onAllPermissionsGranted()
        } else {
            handlePermissionsDenied(permissions)
        }
    }

    // Battery optimization settings launcher
    private val batteryOptimizationLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        // Check if battery optimization was disabled
        checkBatteryOptimization()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initializeViewModel()
        setupUI()
        checkPermissionsAndStart()
    }

    /**
     * Initialize ViewModel and observe LiveData
     */
    private fun initializeViewModel() {
        viewModel = ViewModelProvider(this)[MainViewModel::class.java]
        
        // Observe service status
        viewModel.serviceStatus.observe(this) { isRunning ->
            updateServiceStatus(isRunning)
        }

        // Observe error messages
        viewModel.errorMessage.observe(this) { message ->
            message?.let {
                showError(it)
                viewModel.clearError()
            }
        }
    }

    /**
     * Setup UI elements and click listeners
     */
    private fun setupUI() {
        binding.apply {
            // Service control buttons
            btnStartService.setOnClickListener {
                if (checkAllPermissions()) {
                    startVoiceService()
                } else {
                    requestPermissions()
                }
            }

            btnStopService.setOnClickListener {
                stopVoiceService()
            }

            // Settings and help buttons
            btnSettings.setOnClickListener {
                openAppSettings()
            }

            btnBatteryOptimization.setOnClickListener {
                requestBatteryOptimizationExemption()
            }

            btnHelp.setOnClickListener {
                showHelpDialog()
            }

            // Test buttons for development
            btnTestCall.setOnClickListener {
                testCall()
            }

            btnTestNavigation.setOnClickListener {
                testNavigation()
            }
        }

        updateServiceStatus(VoiceService.isRunning)
    }

    /**
     * Check permissions and start service if ready
     */
    private fun checkPermissionsAndStart() {
        if (checkAllPermissions()) {
            checkBatteryOptimization()
            // Auto-start service if permissions are already granted
            if (!VoiceService.isRunning) {
                startVoiceService()
            }
        } else {
            requestPermissions()
        }
    }

    /**
     * Check if all required permissions are granted
     */
    private fun checkAllPermissions(): Boolean {
        return requiredPermissions.all { permission ->
            ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
        }
    }

    /**
     * Request all required permissions
     */
    private fun requestPermissions() {
        permissionLauncher.launch(requiredPermissions)
    }

    /**
     * Handle when all permissions are granted
     */
    private fun onAllPermissionsGranted() {
        Toast.makeText(this, "Permisos concedidos. Iniciando servicio...", Toast.LENGTH_SHORT).show()
        checkBatteryOptimization()
        startVoiceService()
    }

    /**
     * Handle when some permissions are denied
     */
    private fun handlePermissionsDenied(permissions: Map<String, Boolean>) {
        val deniedPermissions = permissions.filter { !it.value }.keys
        
        val criticalDenied = deniedPermissions.intersect(
            setOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE
            )
        )

        if (criticalDenied.isNotEmpty()) {
            showError(
                "Permisos críticos denegados: ${criticalDenied.joinString()}. " +
                "La aplicación no puede funcionar sin estos permisos."
            )
            binding.btnSettings.isEnabled = true
        } else {
            Toast.makeText(
                this, 
                "Algunos permisos opcionales fueron denegados. La funcionalidad puede ser limitada.",
                Toast.LENGTH_LONG
            ).show()
            startVoiceService() // Start with limited functionality
        }
    }

    /**
     * Start Voice Service
     */
    private fun startVoiceService() {
        val intent = Intent(this, VoiceService::class.java).apply {
            action = VoiceService.ACTION_START_SERVICE
        }
        startForegroundService(intent)
        
        viewModel.updateServiceStatus(true)
        Toast.makeText(this, "Servicio de voz iniciado", Toast.LENGTH_SHORT).show()
    }

    /**
     * Stop Voice Service
     */
    private fun stopVoiceService() {
        val intent = Intent(this, VoiceService::class.java).apply {
            action = VoiceService.ACTION_STOP_SERVICE
        }
        startService(intent)
        
        viewModel.updateServiceStatus(false)
        Toast.makeText(this, "Servicio de voz detenido", Toast.LENGTH_SHORT).show()
    }

    /**
     * Update UI based on service status
     */
    private fun updateServiceStatus(isRunning: Boolean) {
        binding.apply {
            if (isRunning) {
                tvServiceStatus.text = "🔊 Servicio activo - Te escucho"
                tvServiceStatus.setTextColor(ContextCompat.getColor(this@MainActivity, android.R.color.holo_green_dark))
                btnStartService.isEnabled = false
                btnStopService.isEnabled = true
                cardServiceInfo.setCardBackgroundColor(
                    ContextCompat.getColor(this@MainActivity, android.R.color.holo_green_light)
                )
            } else {
                tvServiceStatus.text = "🔇 Servicio inactivo"
                tvServiceStatus.setTextColor(ContextCompat.getColor(this@MainActivity, android.R.color.holo_red_dark))
                btnStartService.isEnabled = true
                btnStopService.isEnabled = false
                cardServiceInfo.setCardBackgroundColor(
                    ContextCompat.getColor(this@MainActivity, android.R.color.darker_gray)
                )
            }
        }
    }

    /**
     * Check and request battery optimization exemption
     */
    private fun checkBatteryOptimization() {
        val powerManager = getSystemService(POWER_SERVICE) as android.os.PowerManager
        if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
            binding.tvBatteryWarning.visibility = android.view.View.VISIBLE
            binding.btnBatteryOptimization.visibility = android.view.View.VISIBLE
        } else {
            binding.tvBatteryWarning.visibility = android.view.View.GONE
            binding.btnBatteryOptimization.visibility = android.view.View.GONE
        }
    }

    /**
     * Request battery optimization exemption
     */
    private fun requestBatteryOptimizationExemption() {
        val intent = Intent().apply {
            action = Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
            data = Uri.parse("package:$packageName")
        }
        batteryOptimizationLauncher.launch(intent)
    }

    /**
     * Open app settings
     */
    private fun openAppSettings() {
        val intent = Intent().apply {
            action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
            data = Uri.parse("package:$packageName")
        }
        startActivity(intent)
    }

    /**
     * Show help dialog
     */
    private fun showHelpDialog() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Ayuda - Petal Manos Libres")
            .setMessage("""
                Comandos disponibles:
                
                📞 LLAMADAS:
                • "Llama a [número]"
                • "Llama a 611 223 344"
                
                🗺️ NAVEGACIÓN:
                • "Ir a [destino]"
                • "Navegar a Casa Carmela"
                • "Llévame a Valencia"
                
                ℹ️ INFORMACIÓN:
                • "¿Cómo está el tráfico?"
                • "Batería"
                • "¿Qué hora es?"
                
                🔧 CONSEJOS:
                • Habla claramente y pausado
                • Usa comandos en español
                • El servicio debe estar activo (ícono en notificaciones)
            """.trimIndent())
            .setPositiveButton("Entendido", null)
            .show()
    }

    /**
     * Test call functionality
     */
    private fun testCall() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) 
            == PackageManager.PERMISSION_GRANTED) {
            
            // Test with emergency number (won't actually call)
            val testIntent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.parse("tel:112")
            }
            
            Toast.makeText(this, "Funcionalidad de llamada: OK", Toast.LENGTH_SHORT).show()
            // Don't actually start the intent for test
        } else {
            showError("Permiso de llamada no concedido")
        }
    }

    /**
     * Test navigation functionality
     */
    private fun testNavigation() {
        val testIntent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("google.navigation:q=Valencia,Spain&mode=b")
        }
        
        if (testIntent.resolveActivity(packageManager) != null) {
            Toast.makeText(this, "Funcionalidad de navegación: OK", Toast.LENGTH_SHORT).show()
        } else {
            showError("Google Maps no está instalado")
        }
    }

    /**
     * Show error message
     */
    private fun showError(message: String) {
        Toast.makeText(this, "Error: $message", Toast.LENGTH_LONG).show()
    }

    /**
     * Extension function to join collection as string
     */
    private fun Collection<String>.joinString(): String {
        return this.joinToString(", ")
    }

    override fun onResume() {
        super.onResume()
        // Update service status when returning to app
        viewModel.updateServiceStatus(VoiceService.isRunning)
        checkBatteryOptimization()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Don't stop service when activity is destroyed - hands-free should continue
    }
}