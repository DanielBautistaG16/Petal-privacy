# 🎤 Petal Handsfree - Android POC

**Asistente de voz manos libres para ciclistas** construido con **Kotlin + MVVM + Jetpack Components** y **Google Gemini API**.

## 📱 Características Principales

### 🎯 **Funcionalidad Core**
- **Reconocimiento continuo de voz** con SpeechRecognizer
- **Procesamiento inteligente** con Gemini 1.5 Flash API
- **Síntesis de voz** para respuestas automáticas
- **Servicio en primer plano** para máxima confiabilidad
- **Fallback offline** para comandos básicos

### 🚀 **Acciones Soportadas**
- **📞 Llamadas**: "Llama a 611 223 344"
- **🗺️ Navegación**: "Ir a Casa Carmela" (modo bicicleta)
- **💬 Conversación**: "¿Cómo está el tráfico?"
- **ℹ️ Sistema**: "Batería", "¿Qué hora es?"

### 🏗️ **Arquitectura**
- **MVVM Pattern** con ViewModels y LiveData
- **Foreground Service** para máxima disponibilidad
- **Coroutines + Flow** para programación asíncrona
- **Dependency Injection ready** para escalabilidad

---

## 🛠️ **Configuración e Instalación**

### 📋 **Prerrequisitos**
- **Android Studio** Giraffe+ (2023.2.1 o superior)
- **Kotlin** 1.9.10+
- **Android SDK** 26+ (Android 8.0+)
- **Google Gemini API Key** ([obtener aquí](https://makersuite.google.com/app/apikey))

### ⚡ **Setup Rápido**

1. **Clonar el repositorio**
   ```bash
   git clone <repository-url>
   cd PetalApp-Android
   ```

2. **Configurar API Key**
   
   Edita `gradle.properties`:
   ```properties
   GEMINI_API_KEY=tu_api_key_aqui
   ```
   
   O usa variables de entorno:
   ```bash
   export GEMINI_API_KEY="tu_api_key_aqui"
   ```

3. **Compilar y ejecutar**
   ```bash
   ./gradlew assembleDebug
   # O desde Android Studio: Run > Run 'app'
   ```

---

## 🧪 **Testing POC - Criterios de Aceptación**

### ✅ **AA1: Inicialización del Servicio**
```
DADO que abro la aplicación
CUANDO presiono "Iniciar Servicio"  
ENTONCES el TTS dice: "Petal manos libres activo. Te escucho."
Y aparece notificación permanente
```

### ✅ **AA2: Comando de Llamada**
```
DADO que el servicio está activo
CUANDO digo "llama a 611 223 344"
ENTONCES se inicia la llamada
Y TTS confirma: "Llamando a 611 223 344"
```

### ✅ **AA3: Comando de Navegación**
```
DADO que el servicio está activo  
CUANDO digo "ir a Casa Carmela"
ENTONCES se abre Google Maps en modo bicicleta
Y TTS confirma: "Navegando a Casa Carmela en modo bicicleta"
```

### ✅ **AA4: Consulta Inteligente**
```
DADO que hay conexión a internet
CUANDO digo "¿cómo está el tráfico?"
ENTONCES Gemini procesa la consulta
Y TTS responde con información relevante
```

### ✅ **AA5: Modo Offline**
```
DADO que NO hay conexión a internet
CUANDO digo "batería"
ENTONCES responde offline: "El nivel de batería es del X por ciento"
```

### ✅ **AA6: Recuperación de Errores**
```
DADO que ocurre un error de STT
CUANDO el reconocimiento falla
ENTONCES se reinicia automáticamente (hasta 3 intentos)
Y el servicio continúa funcionando
```

### ✅ **AA7: Persistencia del Servicio**
```
DADO que el servicio está activo con wake lock
CUANDO la app va a segundo plano
ENTONCES el servicio continúa escuchando
Y la notificación permanece visible
```

---

## 📱 **Uso de la Aplicación**

### 🎬 **Flujo Básico**
1. **Abrir app** → Conceder permisos (micrófono, llamadas, ubicación)
2. **Presionar "Iniciar"** → Servicio se activa con notificación
3. **Hablar comandos** → La app procesa y ejecuta acciones
4. **Escuchar respuestas** → TTS confirma cada acción

### 🗣️ **Comandos Soportados**

#### 📞 **Llamadas**
```
"Llama a 611 223 344"
"Marcar 666 555 444" 
"Telefono 912 345 678"
```

#### 🗺️ **Navegación**
```
"Ir a Casa Carmela"
"Navegar a Valencia Centro"
"Llévame a la farmacia"
"Ve a Madrid"
```

#### 💬 **Información y Chat**
```
"¿Cómo está el tráfico?"
"¿Qué tiempo hace?"
"Cuéntame un chiste"
```

#### ⚙️ **Sistema**
```
"Batería" → Nivel de batería
"¿Qué hora es?" → Hora actual
```

---

## 🏗️ **Arquitectura Técnica**

### 📦 **Estructura del Proyecto**
```
com/petal/handsfree/
├── 📱 MainActivity.kt              # UI principal + permisos
├── 🎤 service/
│   └── VoiceService.kt            # Foreground service core
├── 🧠 processor/
│   └── VoiceProcessor.kt          # Lógica de procesamiento
├── 🌐 client/
│   └── GeminiClient.kt           # Integración API Gemini
├── 🛠️ utils/
│   ├── CallHandler.kt            # Gestión de llamadas
│   ├── NavigationHandler.kt      # Navegación + Maps
│   └── TtsHelper.kt             # Síntesis de voz
└── 📊 viewmodel/
    └── MainViewModel.kt          # MVVM ViewModel
```

### 🔄 **Flujo de Datos**
```
[Voz] → SpeechRecognizer → VoiceProcessor
                              ↓
                         [¿Offline match?]
                              ↓
                    [No] → GeminiClient → API
                              ↓
                      [Intent + Argument]
                              ↓
                   CallHandler / NavigationHandler
                              ↓
                        TtsHelper → [Respuesta]
```

### 🔧 **Componentes Clave**

#### **VoiceService** 
- Foreground Service con notificación persistente
- Wake lock para prevenir suspensión  
- RecognitionListener para STT continuo
- Manejo robusto de errores con reintentos

#### **VoiceProcessor**
- Patrones regex offline para velocidad
- Fallback a Gemini API para consultas complejas
- Routing de intents a handlers específicos

#### **GeminiClient**
- HTTP client con timeouts optimizados
- Prompt engineering para respuestas estructuradas
- Parsing robusto de respuestas JSON

---

## ⚙️ **Configuración Avanzada**

### 🔐 **Permisos Requeridos**
```xml
<!-- Core functionality -->
<uses-permission android:name="android.permission.RECORD_AUDIO"/>
<uses-permission android:name="android.permission.CALL_PHONE"/>
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>

<!-- Service reliability -->
<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
<uses-permission android:name="android.permission.WAKE_LOCK"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
```

### 🔋 **Optimización de Batería**
La app solicita automáticamente exención de optimización de batería para garantizar el funcionamiento continuo en segundo plano.

### 🌐 **Configuración API**
```kotlin
// BuildConfig values
GEMINI_API_KEY: String           # Tu clave API
GEMINI_BASE_URL: String          # Endpoint base de Gemini
```

---

## 🔮 **Roadmap y TODOs**

### 🚧 **Próximas Funcionalidades**

#### 🔊 **Hotword Detection**
```kotlin
// TODO: Implement "Oye Petal" wake word
// usando VoiceInteractionService o librerías externas
class PetalVoiceInteractionService : VoiceInteractionService()
```

#### 📱 **WhatsApp Integration**  
```kotlin
// TODO: AccessibilityService para leer/responder mensajes
class WhatsAppAccessibilityService : AccessibilityService()
```

#### ☁️ **Cloud Sync**
```kotlin
// TODO: Firestore integration para historial y comunidad
implementation 'com.google.firebase:firebase-firestore-ktx'
```

#### 🗺️ **Maps SDK + Offline**
```kotlin
// TODO: Maps SDK con tiles offline
implementation 'com.google.android.gms:play-services-maps:18.2.0'
```

#### 🚴 **Auto-Activation**
```kotlin
// TODO: Detección automática de velocidad ciclismo
if (speed > 6.kmh) activateHandsfree()
```

#### 📊 **Analytics & Crash Reporting**
```kotlin
// TODO: Firebase Analytics + Crashlytics  
implementation 'com.google.firebase:firebase-analytics-ktx'
implementation 'com.google.firebase:firebase-crashlytics-ktx'
```

### 🐛 **Bugs Conocidos**
- [ ] STT puede fallar en ambientes muy ruidosos
- [ ] Primer inicio de TTS puede tomar varios segundos  
- [ ] Algunos dispositivos requieren reinicio tras cambios de permisos

### 💡 **Mejoras Pendientes**
- [ ] Configuración de sensibilidad de voz
- [ ] Soporte para múltiples idiomas
- [ ] Comandos personalizables por usuario
- [ ] Integración con Spotify/música
- [ ] Modo nocturno/luz baja

---

## 🔍 **Troubleshooting**

### ❌ **Problemas Comunes**

#### **"El micrófono no funciona"**
```bash
# Verificar permisos
adb shell dumpsys package com.petal.handsfree | grep RECORD_AUDIO

# Solución: Ir a Configuración > Apps > Petal > Permisos
```

#### **"Gemini API devuelve errores"**
```bash
# Verificar API key
echo $GEMINI_API_KEY

# Testear endpoint manualmente
curl -X POST "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$GEMINI_API_KEY"
```

#### **"El servicio se cierra inesperadamente"**
```bash
# Revisar logs
adb logcat -s VoiceService

# Deshabilitar optimización de batería
Settings > Battery > Battery Optimization > Petal Handsfree > Don't optimize
```

#### **"Las llamadas no funcionan"**
```bash
# Verificar app de teléfono por defecto
adb shell cmd role get-default android.app.role.DIALER

# Testear intent manualmente
adb shell am start -a android.intent.action.CALL -d "tel:611223344"
```

### 📊 **Debug y Logs**
```bash
# Logs completos de la app
adb logcat -s PetalApp VoiceService GeminiClient

# Filtrar solo errores
adb logcat -s PetalApp:E VoiceService:E

# Logs de sistema relevantes
adb logcat -s AudioManager PackageManager ActivityManager
```

---

## 🤝 **Contribución**

### 🔧 **Development Setup**
```bash
# Pre-commit hooks
./gradlew installGitHooks

# Code style
./gradlew ktlintFormat

# Tests
./gradlew test
```

### 📋 **Pull Request Guidelines**
1. **Feature branch** desde `develop`
2. **Tests unitarios** para nueva funcionalidad  
3. **Documentación** actualizada
4. **Changelog** entry

---

## 📄 **Licencia**

```
Copyright 2024 Petal Team

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
```

---

## 📞 **Soporte**

- 🐛 **Issues**: [GitHub Issues](https://github.com/petal/handsfree-android/issues)
- 💬 **Discusiones**: [GitHub Discussions](https://github.com/petal/handsfree-android/discussions)  
- 📧 **Email**: support@petal.com
- 🌐 **Web**: [https://ridepetal.com](https://ridepetal.com)

---

**¡Pedala seguro con Petal Handsfree! 🚴‍♂️🎤**